#include <stdio.h>

int main()
{
    int N;
    scanf("%d", &N);
    if (N % 2 == 0)
    {
        printf("Even");
    }
    else
    {
        printf("Odd");
    }

    // leave the second approach, if you haven't studied DLD till now.
}