#include <stdio.h>
#include <string.h>

// don't worry about these, for now

// ok so you have to store info in computer
// ok, tell what is storage of your phone or laptop
// 128GB OR 256GB
// so what is it?

// it is nothing but a lot of bytes
// what is a byte?

// just understand, it is the basic unit of storage in computer
// it is a single block, smallest single block, just understand this

// so now, let's move to the question

// there are different types of data
// integers, decimals, characters, words etc

// isn't?

// so we use different terms
// int, float, char, char list (technically called, array) to store these data in computer

// roll number is int
int roll_number = 1234;

// student name is "Ali Ahmad"
char student_name[] = "Ali Ahmed";

// student cgpa is float
float cgpa = 3.75;

// student attendance percentage is float
float att_percentage = 89.5

    // as simple as that

    // these are comments, remember?
